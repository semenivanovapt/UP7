﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WPF_Ivanov_PR7_UP
{
    internal class Q3Frame
    {
        public static RadioButton QRB3;
    }
}
