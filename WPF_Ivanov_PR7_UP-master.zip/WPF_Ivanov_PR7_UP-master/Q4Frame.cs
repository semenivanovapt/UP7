﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WPF_Ivanov_PR7_UP-master
{
    internal class Q4Frame
    {
        public static RadioButton QRB4;
    }
}
